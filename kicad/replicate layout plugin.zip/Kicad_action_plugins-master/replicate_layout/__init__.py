from .action_replicate_layout import ReplicateLayout # Note the relative import!
ReplicateLayout().register() # Instantiate and register to Pcbnew